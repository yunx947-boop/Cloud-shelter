import { Hero } from '@/components/hero'
import { CloudIslands } from '@/components/cloud-islands'
import { SiteFooter } from '@/components/site-footer'

export default function Page() {
  return (
    <main>
      <Hero />
      {/* 卡片网格上方额外呼吸空间；网格与页脚间距 80px */}
      <div className="pt-8 pb-20">
        <CloudIslands />
      </div>
      <SiteFooter />
    </main>
  )
}
