import { Reveal } from '@/components/reveal'

/* 云岛导航数据：可在此增删条目 */
const islands = [
  { icon: '🪶', title: '迷途集', desc: '一些没想完的话' },
  { icon: '📖', title: '单向书', desc: '在单行道上写的信' },
  { icon: '🎧', title: '留声机', desc: '声音是另一种云' },
  { icon: '🤖', title: '树洞回响', desc: '说给空气，空气会回' },
  { icon: '🌫️', title: '关于此间', desc: '这里为什么存在' },
  { icon: '✦', title: '预留', desc: '更多可能' },
]

export function CloudIslands() {
  return (
    <section className="px-6 lg:px-[60px]">
      {/* 板块小标题：12px / 300 / #B5B5B5 / 字距 4px，与网格间距 48px */}
      <Reveal>
        <p className="mb-12 text-center text-xs font-light uppercase tracking-[4px] text-ink-faint">
          此处可栖
        </p>
      </Reveal>

      {/* 卡片网格：gap 32px，卡片 min 200 / max 240 */}
      <ul className="mx-auto flex max-w-5xl list-none flex-wrap justify-center gap-8">
        {islands.map((item, i) => (
          <Reveal
            key={item.title}
            as="li"
            /* 逐个 stagger：0.08s 递增 */
            delay={i * 0.08}
            className="w-[80%] min-w-[200px] max-w-[240px] sm:w-auto sm:flex-[0_0_200px]"
          >
            <a
              href="#"
              className="glass glass-hover block h-full px-6 py-7 text-center"
            >
              {/* 图标 32px */}
              <span className="block text-[32px] leading-none" aria-hidden="true">
                {item.icon}
              </span>
              {/* 标题 16px / 400 / #4A4A4A */}
              <span className="mt-3 block text-base font-normal leading-relaxed text-ink">
                {item.title}
              </span>
              {/* 描述 14px / 300 / #8A8A8A */}
              <span className="mt-1 block text-sm font-light leading-relaxed text-ink-sub">
                {item.desc}
              </span>
            </a>
          </Reveal>
        ))}
      </ul>
    </section>
  )
}
