import { Reveal } from '@/components/reveal'

export function Hero() {
  return (
    <section className="flex min-h-screen flex-col px-6 lg:px-[60px]">
      {/* 顶部留白 8% */}
      <div className="h-[8vh] shrink-0" aria-hidden="true" />

      {/* 顶部装饰线：宽 60% 居中，#D9D0C5 → transparent */}
      <Reveal delay={0.2} className="mx-auto w-[60%]">
        <div
          className="h-px w-full"
          style={{ background: 'linear-gradient(to right, transparent, #d9d0c5, transparent)' }}
          aria-hidden="true"
        />
      </Reveal>

      {/* 网站名：24px / 300 / #8A8A8A */}
      <Reveal delay={0.2}>
        <h1 className="mt-10 text-center text-[24px] font-light tracking-wide text-ink-sub">
          云端庇护所
        </h1>
      </Reveal>

      {/* 中央区域 */}
      <div className="flex flex-1 flex-col items-center justify-center">
        {/* 插画占位：宽高比 3:4 容器，#F5F0EB → #E8E0DA 渐变，居中极淡云朵 SVG */}
        {/* TODO: 后期只需替换本容器内部内容（如填入 <img>/<Image> 白发猫耳娘插画） */}
        <Reveal delay={0.4} className="flex w-full justify-center">
          <div
            className="flex aspect-[3/4] w-[70%] max-w-xs items-center justify-center overflow-hidden rounded-[32px] sm:w-[55%]"
            style={{ background: 'linear-gradient(to bottom, #f5f0eb, #e8e0da)' }}
          >
            {/* 极淡云朵占位图标 */}
            <svg
              viewBox="0 0 64 40"
              className="w-2/5 text-ink-faint opacity-30"
              fill="currentColor"
              aria-hidden="true"
            >
              <path d="M50 26a10 10 0 0 0-1.4-.1 14 14 0 0 0-27-5.2A9 9 0 0 0 12 29a9 9 0 0 0 9 9h29a6 6 0 0 0 0-12Z" />
            </svg>
            <span className="sr-only">插画占位</span>
          </div>
        </Reveal>

        {/* 标语：22px / 300 / #4A4A4A / 行高 1.8 */}
        <Reveal delay={0.6}>
          <p className="mt-8 text-center text-[22px] font-light leading-[1.8] text-ink text-pretty">
            迷路也没关系，这里可以坐下歇歇。
          </p>
        </Reveal>
      </div>

      {/* 底部滚动指示：极淡圆点 */}
      <Reveal delay={0.6} className="flex h-[8vh] shrink-0 items-center justify-center">
        <span className="h-2 w-2 animate-pulse rounded-full bg-ink-faint opacity-40" aria-hidden="true" />
      </Reveal>
    </section>
  )
}
