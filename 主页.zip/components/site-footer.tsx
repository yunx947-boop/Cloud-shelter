import { Reveal } from '@/components/reveal'

export function SiteFooter() {
  return (
    <footer className="px-6 pb-16 lg:px-[60px]">
      <Reveal>
        {/* 页脚文字：13px / 300 / #B5B5B5 / 行高 2 */}
        <div className="text-center text-[13px] font-light leading-[2] text-ink-faint">
          <p>时间不回，迷途不惧。</p>
          <p>追云而去，缓缓前行。</p>
          <p>温柔以对，包容所有。</p>
        </div>
        <p className="mt-4 text-center text-[13px] font-light leading-[2] text-ink-faint opacity-70">
          云层于 2026.09 翻新
        </p>
      </Reveal>
    </footer>
  )
}
